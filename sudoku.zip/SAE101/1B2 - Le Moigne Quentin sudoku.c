/**
*
* \page Programme Programme d'un sudoku
*
* \author LE MOIGNE Quentin
*
* \version 1.0
*
* \date 26 novembre 2023
*
* Ce programme propose de jouer au sudoku à l'aide de grille
* dèjà générer en demandant à l'utilisateur un fichier de
* grille et les numéros de case et leur valeur.
*
*/

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>





//déclaration des constante

/**
*
* \def TAILLE
*
* \brief constante pour la taille de la largeur d'une grille.
*
*/
#define TAILLE 9

/**
*
* @var N
*
* \brief La largeur d'un carré
*
*/
const int N = 3;

/**
*
* @var NB_TIRET
*
* \brief Nombre de tiret necessaire pour l'affichage de la grille
*
*/
const int NB_TIRET = 9;

/**
*
* @var TIRET
*
* \brief Caractère principal de la ligne pour la séparation dans l'affichage de la grille.
*
*/
const char TIRET = '-';

/**
*
* @var INTERSECTION
*
* \brief Caractère principal de l'intersection pour la séparation d'entre les lignes/colonnes pour l'affichage de la grille.
*
*/
const char INTERSECTION = '+';

/**
*
* @var BARRE
*
* \brief Caractère principal de la colonne pour la séparation dans l'affichage de la grille.
*
*/
const char BARRE = '|';

/**
*
* @var VALEUR_NULLE
*
* \brief Caractère à afficher dans la grille si il y a un 0
*
*/
const char VALEUR_NULLE = '.';

//Déclaration des types

/**
*
* \typedef tGrille
*
* \brief type matrice de TAILLE*TAILLE caractères
*
* Le type tGrille sert de grille pour le sudoku avec
* pour éléments les valeurs déjà présentes et les valeurs
* rajoutées par l'utilisateur
*
*/
typedef int tGrille[TAILLE][TAILLE];

//Prototypes des fonctions et procédures
void chargerGrille(tGrille *g);
void afficherGrille (tGrille t);
void saisir (int *valeurSaisie);
bool possible (tGrille grille, int numLig, int numCol, int valInsert);
bool grillePleine(tGrille grille);

int main(){
    //déclaration des variables
    int numLigne;
    int numColonne;
    int valeur;
    tGrille grille1;

    chargerGrille(&grille1);

    while (grillePleine(grille1) == false){
        afficherGrille(grille1);

        // saisie des données
        printf("Indices de la case ? ");
        saisir(&numLigne);
        saisir(&numColonne);
        numLigne = numLigne - 1;
        numColonne = numColonne - 1;

        // traitement des données
        if (grille1[numLigne][numColonne] != 0){
            printf("IMPOSSIBLE, la case n'est pas libre.\n");
        } else {
            printf("Valeur à insérer ? ");
            saisir(&valeur);
            if (possible(grille1, numLigne, numColonne, valeur)){
                grille1[numLigne][numColonne] = valeur;
            }
        }
    }

    // affichage des résultats
    printf("Grille pleine, fin de partie\n");


   return EXIT_SUCCESS;
}

/**
*
* \fn void chargerGrille(tGrille *g)
*
* \brief Procédure qui charge une grille.
*
* \param g : La grille a chargé
*
* Consiste à charger un tableau entré en paramètre avec un fichier .sud saisi par l'utilisateur
*
*/

void chargerGrille(tGrille *g){
    char nomFichier[30];
    FILE * f;
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    while (f==NULL){
        printf("\n ERREUR sur le fichier %s ! Veuillez saisir un nom de fichier correct \n", nomFichier);

        printf("Nom du fichier ? ");
        scanf("%s", nomFichier);
        f = fopen(nomFichier, "rb");
    }
    fread(*g, sizeof(int), TAILLE*TAILLE, f);
    
}

/**
*
* \fn afficherGrille (tGrille grille)
*
* \brief Procédure qui affiche une grille.
*
* \param grille1 : la grille du sudoku.
*
* Affiche la grille du sudoku avec un formatage
*
*/
void afficherGrille (tGrille grille){
    //Déclaration variables
    int i; // indice de ligne et de ligne de séparation
    int j; // indice de colonne et de ligne de séparation
    int indiceLigne;

    //Numéros de colonne
    printf("\n      1  2  3   4  5  6   7  8  9  \n");


    //Ligne de données
    for (i=0 ; i<TAILLE ; i++){

        //Lignes de séparation
        if (i%3==0){
            printf("    %c",INTERSECTION);
            for (indiceLigne=0;indiceLigne<N;indiceLigne++){
                for (j=0;j<NB_TIRET;j++){
                    printf("%c",TIRET);
                }   
                printf("%c",INTERSECTION);
            }
            printf("\n");
        }

        //Affichage des valeurs
        printf("%d   %c",i+1,BARRE);
        for (j=0 ; j<TAILLE ; j++){
            if (j%3==0 && j!=0){
                printf("%c",BARRE);
            }
            if (grille[i][j] != 0){
                printf(" %d ",grille[i][j]);
            }else{
                printf(" %c ",VALEUR_NULLE);
            }
        }
        printf("%c",BARRE);
        printf("\n");
    }


    //Dernière ligne de séparation
    if (i%3==0){
        printf("    %c",INTERSECTION);
        for (indiceLigne=0;indiceLigne<N;indiceLigne++){
            for (j=0;j<NB_TIRET;j++){
                printf("%c",TIRET);
            }   
            printf("%c",INTERSECTION);
        }
        printf("\n");
    }
}

/**
*
* \fn saisir (int *valeurSaisie)
*
* \brief Procédure qui permet de saisir de la valeur choisie
*
* \param valeurSaisie : la valeur à vérifier et/ou modifier
*
* Vérifie si la valeur saisie est correcte et demande de saisir de nouveau si elle n'est pas correcte.
*
*/
void saisir (int *valeurSaisie){
    char chaine[10];

    scanf("%s", chaine);
    
    //Vérifie validité de la valeur saisie
    while ((sscanf(chaine, "%d", &(*valeurSaisie)) ==0) || (*valeurSaisie<1 || *valeurSaisie>N*N)){
        printf("Erreur ! Veuillez insérer un entier de 1 à %d : ",N*N);
        scanf("%s", chaine);
    }
}

/**
*
* \fn bool possible (tGrille grille, int numLig, int numCol, int valInsert)
*
* \brief Fonction qui indique si la valeur peut être saisie
*
* \param grille : la grille du Sudoku
*
* \param numLig : le numéro de ligne à modifier
*
* \param numCol : le numéro de colonne à modifier
*
* \param valInsert : la valeur à insérer
*
* \return true si la valeur peut être placée, false sinon
*
* Consiste à vérifier si la valeur peut être placée dans la grille avec dans la case saisie.
*
*/
bool possible (tGrille grille, int numLig, int numCol, int valInsert){
    int lig;
    int col;
    bool valPossible;

    valPossible = true;
    //Vérification de la ligne
    for (col=0;col<TAILLE;col++){
        if (grille[numLig][col] == valInsert){
            valPossible = false;
        }
    }

    //Vérification de la colonne
    for (lig=0;lig<TAILLE;lig++){
        if (grille[lig][numCol] == valInsert){
            valPossible = false;
        }
    }

    //Vérification de la case
    for (lig=0;lig<N;lig++){
        for (col=0;col<N;col++){
            if (grille[lig+(numLig/3*3)][col+numCol/3*3] == valInsert){
                valPossible = false;
            }
        }
    }

    if (valPossible == false){
        printf("Erreur ! Vous pouvez placer des valeurs que si elle n'est pas déjà présente dans le carré, la ligne et la colonne.\n");
    }
    return valPossible;
}

/**
*
* \fn bool grillePleine(tGrille grille)
*
* \brief Fonction qui vérifie si la grille est pleine.
*
* \param grille : la grille du Sudoku
*
* \return true si la grille est pleine, false sinon
*
* Consiste à vérifier si la grille est pleine en regardant chaque case de la grille.
*
*/
bool grillePleine(tGrille grille){
    //Déclaration des variables
    int lig;
    int col;
    bool finPartie;

    //Parcours de la grille
    finPartie = true;
    for (lig=0;lig<TAILLE;lig++){
        for (col=0;col<TAILLE;col++){
            if (grille[lig][col] == 0){
                finPartie = false;
            }
        }
    }

    return finPartie;
}
